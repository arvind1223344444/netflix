import React from 'react'

function Notfound() {
  return (
    <>
    <div className='container mt-5'>
        <div className='row mt-5'>
    <center><h2>Page Not found</h2></center>
 </div>
 </div></>
  )
}

export default Notfound