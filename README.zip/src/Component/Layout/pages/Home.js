import React from "react";
import Searchbar from "./Searchbar";
import Middv from "./Middv";  
import Card_dv from "./Card_dv";
import Details from "./Details";
function Home()
{
    return <>
  
   <Searchbar/>
   <Middv/>
   

    </>
}
export default Home;